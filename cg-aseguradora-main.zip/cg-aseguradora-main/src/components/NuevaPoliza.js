"use client";
import React, { useState, useContext, useEffect } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./NuevaPoliza.css";

function NuevaPoliza() {
  const {
    clientesList,
    requestClientesList,
    contactosList,
    requestContactosList,
    mqttClient,
  } = useContext(MQTTContext);

  const [filteredClientes, setFilteredClientes] = useState([]);
  const [filteredContactos, setFilteredContactos] = useState([]);
  const [formData, setFormData] = useState({
    razonSocial: "",
    representante: "",
    ciRuc: "",
    tipoPoliza: "",
    numeroPoliza: "",
    placa: "",
    codigoAsegurado: "",
    fechaEmision: "",
    numeroRenovacion: "",
    vigenciaDesde: "",
    vigenciaHasta: "",
    aseguradora: "",
    primaNeta: "",
    valorTotal: "",
    formaPago: "transferencia",
    numeroDocumento: "",
    pagoEnCuotas: "no",
    numeroCuotas: "",
    fechaPagoInicial: "",
    nombreContacto: "", // ✅ Nuevo campo para nombre de contacto
  });

  useEffect(() => {
    requestClientesList();
    requestContactosList();
  }, []);

  useEffect(() => {
    if (!mqttClient) return;

    const handleResponse = (topic, message) => {
      if (topic === "polizas/respuesta") {
        const msg = message.toString();
        if (msg === "duplicado") {
          alert("⚠️ La póliza ya existe. Intenta con otro número.");
        } else {
          alert("✅ Póliza registrada exitosamente.");
        }
      }
    };

    mqttClient.subscribe("polizas/respuesta");
    mqttClient.on("message", handleResponse);

    return () => {
      mqttClient.removeListener("message", handleResponse);
    };
  }, [mqttClient]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if (!Array.isArray(clientesList) || !Array.isArray(contactosList)) return;

    let coincidenciasClientes = [];
    let coincidenciasContactos = [];

    if (name === "ciRuc") {
      coincidenciasClientes = clientesList.filter((c) =>
        c.ciRuc.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (name === "representante") {
      coincidenciasClientes = clientesList.filter((c) =>
        c.representante.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (name === "nombreContacto") {
      coincidenciasContactos = contactosList.filter((c) =>
        c.nombre.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (name === "ciRuc" || name === "representante") {
      setFilteredClientes(
        coincidenciasClientes.length > 0 && value.trim()
          ? coincidenciasClientes
          : []
      );
    }

    if (name === "nombreContacto") {
      setFilteredContactos(
        coincidenciasContactos.length > 0 && value.trim()
          ? coincidenciasContactos
          : []
      );
    }
  };

  const handleSelectCliente = (cliente) => {
    setFormData({
      ...formData,
      razonSocial: cliente.razonSocial,
      representante: cliente.representante,
      ciRuc: cliente.ciRuc,
    });
    setFilteredClientes([]);
  };

  const handleSelectContacto = (contacto) => {
    setFormData({
      ...formData,
      nombreContacto: contacto.nombre,
    });
    setFilteredContactos([]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = { ...formData };

    mqttClient.publish("polizas/nueva", JSON.stringify(payload));
    console.log("📤 Póliza enviada:", payload);

    if (
      formData.pagoEnCuotas === "si" &&
      formData.numeroCuotas &&
      formData.numeroRenovacion.trim() !== "" &&
      formData.fechaPagoInicial
    ) {
      const cuotaMensual = (
        parseFloat(formData.valorTotal) / parseInt(formData.numeroCuotas)
      ).toFixed(2);
      const fechaInicial = new Date(formData.fechaPagoInicial);
      const cuotas = [];

      for (let i = 0; i < parseInt(formData.numeroCuotas); i++) {
        const fechaPago = new Date(fechaInicial);
        fechaPago.setMonth(fechaPago.getMonth() + i);

        cuotas.push({
          ciRuc: formData.ciRuc,
          numeroPoliza: formData.numeroPoliza,
          numeroRenovacion: formData.numeroRenovacion,
          cuota: i + 1,
          totalCuotas: parseInt(formData.numeroCuotas),
          valor: cuotaMensual,
          fechaPago: fechaPago.toISOString().split("T")[0],
          estadoPago: "pendiente",
          numeroDocumento: formData.numeroDocumento,
          formaPago: formData.formaPago,
        });
      }

      mqttClient.publish("cuotas/nueva", JSON.stringify(cuotas));
      console.log("📄 Cuotas generadas:", cuotas);
    }
  };

  return (
    <div className="form-container">
      <h2 className="form-title">Registrar Nueva Póliza</h2>
      <form onSubmit={handleSubmit}>
        <h3 className="section-title">Datos del Cliente</h3>
        <div className="form-grid cliente-grid">
          <div className="form-group">
            <label>CI / RUC:</label>
            <input
              type="text"
              name="ciRuc"
              value={formData.ciRuc}
              onChange={handleChange}
              autoComplete="off"
              required
            />
          </div>
          <div className="form-group">
            <label>Representante Legal:</label>
            <input
              type="text"
              name="representante"
              value={formData.representante}
              onChange={handleChange}
              autoComplete="off"
            />
          </div>
          {filteredClientes.length > 0 && (
            <ul className="autocomplete-list">
              {filteredClientes.map((cliente) => (
                <li
                  key={cliente.ciRuc}
                  onClick={() => handleSelectCliente(cliente)}
                >
                  {cliente.ciRuc} - {cliente.representante}
                </li>
              ))}
            </ul>
          )}
          <div className="form-group">
            <label>Razón Social:</label>
            <input
              type="text"
              name="razonSocial"
              value={formData.razonSocial}
              readOnly
            />
          </div>
        </div>

        <h3 className="section-title">Datos de la Póliza</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Persona de Contacto:</label>
            <input
              type="text"
              name="nombreContacto"
              value={formData.nombreContacto}
              onChange={handleChange}
              autoComplete="off"
            />
            {filteredContactos.length > 0 && (
              <ul className="autocomplete-list">
                {filteredContactos.map((contacto, index) => (
                  <li
                    key={index}
                    onClick={() => handleSelectContacto(contacto)}
                  >
                    {contacto.nombre}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Resto de tus campos que ya tenías */}
          <div className="form-group">
            <label>Tipo de Póliza:</label>
            <input
              type="text"
              name="tipoPoliza"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>N° Póliza:</label>
            <input
              type="text"
              name="numeroPoliza"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Número de Placa:</label>
            <input type="text" name="placa" onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Código Asegurado:</label>
            <input type="text" name="codigoAsegurado" onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Fecha Emisión:</label>
            <input
              type="date"
              name="fechaEmision"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Número de Renovación:</label>
            <input
              type="text"
              name="numeroRenovacion"
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Vigencia Desde:</label>
            <input
              type="date"
              name="vigenciaDesde"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Vigencia Hasta:</label>
            <input
              type="date"
              name="vigenciaHasta"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Aseguradora:</label>
            <input
              type="text"
              name="aseguradora"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Prima Neta:</label>
            <input
              type="number"
              name="primaNeta"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Valor Total Póliza:</label>
            <input
              type="number"
              name="valorTotal"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Forma de Pago:</label>
            <select
              name="formaPago"
              value={formData.formaPago}
              onChange={handleChange}
            >
              <option value="transferencia">Transferencia</option>
              <option value="deposito">Depósito</option>
              <option value="tarjeta">Tarjeta</option>
              <option value="cheque">Cheque</option>
            </select>
          </div>
          <div className="form-group">
            <label>Número de Documento de Pago:</label>
            <input
              type="text"
              name="numeroDocumento"
              value={formData.numeroDocumento}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>¿Pagar en Cuotas?</label>
            <select
              name="pagoEnCuotas"
              value={formData.pagoEnCuotas}
              onChange={handleChange}
            >
              <option value="no">No</option>
              <option value="si">Sí</option>
            </select>
          </div>
          {formData.pagoEnCuotas === "si" && (
            <>
              <div className="form-group">
                <label>Número de Cuotas:</label>
                <input
                  type="number"
                  name="numeroCuotas"
                  value={formData.numeroCuotas}
                  onChange={handleChange}
                  min="1"
                  required
                />
              </div>
              <div className="form-group">
                <label>Fecha de Pago Inicial:</label>
                <input
                  type="date"
                  name="fechaPagoInicial"
                  value={formData.fechaPagoInicial}
                  onChange={handleChange}
                  required
                />
              </div>
            </>
          )}
        </div>

        <button type="submit" className="submit-button">
          Registrar Póliza
        </button>
      </form>
    </div>
  );
}

export default NuevaPoliza;
