import React, { useState, useEffect, useContext } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./Inicio.css";

function Inicio() {
  const { mqttClient, isConnected } = useContext(MQTTContext);
  const [horaActual, setHoraActual] = useState(new Date().toLocaleTimeString());
  const [polizasProximas, setPolizasProximas] = useState([]);
  const [cuotasProximas, setCuotasProximas] = useState([]);

  const fetchAlertas = () => {
    if (mqttClient && isConnected) {
      mqttClient.publish("alertas/polizas/proximas", "");
      mqttClient.publish("alertas/cuotas/proximas", "");
    }
  };

  const fetchTodas = () => {
    if (mqttClient && isConnected) {
      mqttClient.publish("alertas/polizas/todas", "");
    }
  };

  const actualizarVerificacion = (numeroPoliza, estado) => {
    if (mqttClient && isConnected) {
      mqttClient.publish(
        "polizas/verificar",
        JSON.stringify({ numeroPoliza, verificado: estado })
      );
  
      // Esperar 500 ms para que se actualice en la base de datos
      setTimeout(() => {
        fetchTodas();
      }, 500);
    }
  };
  
  useEffect(() => {
    const interval = setInterval(() => {
      setHoraActual(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!mqttClient || !isConnected) return;

    mqttClient.subscribe("alertas/polizas/respuesta");
    mqttClient.subscribe("alertas/polizas/todas/respuesta");
    mqttClient.subscribe("alertas/cuotas/respuesta");

    fetchAlertas();

    mqttClient.on("message", (topic, message) => {
      if (topic === "alertas/polizas/respuesta" || topic === "alertas/polizas/todas/respuesta") {
        try {
          const data = JSON.parse(message.toString());
          setPolizasProximas(data);
        } catch (err) {
          console.error("❌ Error al parsear pólizas:", err);
        }
      }

      if (topic === "alertas/cuotas/respuesta") {
        try {
          const data = JSON.parse(message.toString());
          setCuotasProximas(data);
        } catch (err) {
          console.error("❌ Error al parsear cuotas:", err);
        }
      }
    });
  }, [mqttClient, isConnected]);

  const formatearFecha = (fecha) => {
    try {
      return new Date(fecha).toLocaleDateString("es-EC", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      });
    } catch {
      return fecha;
    }
  };

  const colorFila = (dias) => {
    if (dias < 5) return "alerta-rojo";      // 🔴 Vencidas (días negativos)
    if (dias <= 15) return "alerta-amarillo"; // 🟡 Muy próximas (0 a 5 días)
    if (dias <= 30) return "alerta-verde";   // 🟢 Pronto (6 a 15 días)
    return "";                              // Sin alerta (más lejos)
  };
  

  return (
    <div className="inicio-container">
      <div className="encabezado-flex">
        <h1 className="titulo">Bienvenido</h1>
        <h2 className="reloj">🕒 {horaActual}</h2>
      </div>

      <div className="tabla-wrapper">
        <h3>📆 Pólizas que expiran en ≤ 30 días</h3>
        <table className="tabla con-bordes">
          <thead>
            <tr>
              <th>Número</th>
              <th>Cliente</th>
              <th>Vigencia Hasta</th>
              <th>Días restantes</th>
              <th>Verificado</th>
            </tr>
          </thead>
          <tbody>
            {polizasProximas.length === 0 ? (
              <tr><td colSpan="5" className="vacía">No hay pólizas próximas</td></tr>
            ) : (
              polizasProximas.map((p, i) => (
                <tr key={i} className={colorFila(p.diasRestantes)}>
                  <td>{p.numeroPoliza}</td>
                  <td>{p.razonSocial}</td>
                  <td>{formatearFecha(p.vigenciaHasta)}</td>
                  <td>{p.diasRestantes}</td>
                  <td>
                    <input
                      type="checkbox"
                      checked={p.verificado === 1}
                      onChange={(e) => actualizarVerificacion(p.numeroPoliza, e.target.checked ? 1 : 0)}
                      title="Marcar como verificado"
                    />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        <div className="actualizar-wrapper abajo">
          <button className="btn-actualizar" onClick={fetchAlertas}>🔄 Actualizar ahora</button>
          <button className="btn-ver-todo" onClick={fetchTodas}>📋 Ver todo</button>
        </div>
      </div>

      <div className="tabla-wrapper">
        <h3>💰 Cuotas por cobrar en ≤ 10 días o vencidas</h3>
        <table className="tabla con-bordes">
          <thead>
            <tr>
              <th>Póliza</th>
              <th>Cuota</th>
              <th>Fecha Pago</th>
              <th>Días Diferencia</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {cuotasProximas.length === 0 ? (
              <tr><td colSpan="5" className="vacía">No hay cuotas próximas</td></tr>
            ) : (
              cuotasProximas.map((c, i) => (
                <tr key={i} className={colorFila(c.diasDiferencia)}>
                  <td>{c.numeroPoliza}</td>
                  <td>{c.cuota}</td>
                  <td>{formatearFecha(c.fechaPago)}</td>
                  <td>{c.diasDiferencia}</td>
                  <td>{c.estadoPago}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Inicio;
