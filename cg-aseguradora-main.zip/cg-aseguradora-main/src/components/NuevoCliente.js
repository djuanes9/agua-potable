"use client";
import React, { useState, useContext, useEffect } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./NuevoCliente.css";

const NuevoCliente = () => {
  const {
    sendNewClient,
    serverResponse,
    isConnected,
    clientesList = [],
    requestClientesList,
  } = useContext(MQTTContext);

  const [formData, setFormData] = useState({
    razonSocial: "",
    representante: "",
    ciRuc: "",
    direccion: "",
    celular: "",
    telefono: "",
    correo: "",
    fechaNacimiento: "",
    agente: "",
  });

  const [filteredClientes, setFilteredClientes] = useState([]);
  const [busqueda, setBusqueda] = useState("");

  useEffect(() => {
    requestClientesList(); // ✅ Pedir clientes cuando se abre esta vista
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if (!Array.isArray(clientesList)) return;

    let coincidencias = [];

    if (name === "ciRuc") {
      coincidencias = clientesList.filter((c) =>
        c.ciRuc.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (name === "razonSocial") {
      coincidencias = clientesList.filter((c) =>
        c.razonSocial.toLowerCase().includes(value.toLowerCase())
      );
    }

    if (name === "ciRuc" || name === "razonSocial") {
      setFilteredClientes(
        coincidencias.length > 0 && value.trim() ? coincidencias : []
      );
    }
  };

  const handleSelectCliente = (cliente) => {
    setFormData({
      razonSocial: cliente.razonSocial,
      representante: cliente.representante,
      ciRuc: cliente.ciRuc,
      direccion: cliente.direccion,
      celular: cliente.celular,
      telefono: cliente.telefono,
      correo: cliente.correo,
      fechaNacimiento: cliente.fechaNacimiento,
      agente: cliente.agente,
    });
    setFilteredClientes([]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendNewClient(formData);
  };

  return (
    <div className="form-container">
      <h2 className="form-title">Registrar Nuevo Cliente</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-group">
            <label>Razón Social:</label>
            <input
              type="text"
              name="razonSocial"
              value={formData.razonSocial}
              onChange={handleChange}
              autoComplete="off"
              required
            />
          </div>

          <div className="form-group">
            <label>Representante Legal:</label>
            <input
              type="text"
              name="representante"
              value={formData.representante}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>C.I / RUC:</label>
            <input
              type="text"
              name="ciRuc"
              value={formData.ciRuc}
              onChange={handleChange}
              autoComplete="off"
              required
            />
          </div>

          {filteredClientes.length > 0 && (
            <ul className="autocomplete-list">
              {filteredClientes.map((cliente) => (
                <li
                  key={cliente.ciRuc}
                  onClick={() => handleSelectCliente(cliente)}
                >
                  {cliente.ciRuc} - {cliente.razonSocial}
                </li>
              ))}
            </ul>
          )}

          {/* --- El resto de campos --- */}
          <div className="form-group">
            <label>Dirección:</label>
            <input
              type="text"
              name="direccion"
              value={formData.direccion}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Celular:</label>
            <input
              type="text"
              name="celular"
              value={formData.celular}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Teléfono Convencional:</label>
            <input
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label>Correo:</label>
            <input
              type="email"
              name="correo"
              value={formData.correo}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Fecha de Nacimiento:</label>
            <input
              type="date"
              name="fechaNacimiento"
              value={formData.fechaNacimiento}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Agente:</label>
            <input
              type="text"
              name="agente"
              value={formData.agente}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <button type="submit" className="submit-button" disabled={!isConnected}>
          {isConnected ? "Registrar Cliente" : "Esperando conexión..."}
        </button>

        {serverResponse && (
          <p className="form-response">📩 Respuesta: {serverResponse}</p>
        )}
      </form>
    </div>
  );
};

export default NuevoCliente;
