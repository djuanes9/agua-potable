"use client";
import React, { useState, useContext } from "react";
import { MQTTContext } from "./MQTTCliente"; // Importa el contexto MQTT
import "./NuevoCliente.css"; // ✅ Usamos el mismo diseño para mantener consistencia

const NuevoContacto = () => {
  const mqttContext = useContext(MQTTContext);

  const [formData, setFormData] = useState({
    nombre: "",
    telefono: "",
    correo: "",
  });

  if (!mqttContext) {
    console.error(
      "❌ MQTTContext no está definido. Verifica que MQTTProvider está envolviendo la app."
    );
    return <p>❌ Error: No se pudo conectar a MQTT.</p>;
  }

  const { sendNewContact, serverResponse, isConnected } = mqttContext;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendNewContact(formData);
  };

  return (
    <div className="form-container">
      <h2 className="form-title">Registrar Nueva Persona de Contacto</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <div className="form-group">
            <label>Nombre:</label>
            <input
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Teléfono:</label>
            <input
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Correo:</label>
            <input
              type="email"
              name="correo"
              value={formData.correo}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <button type="submit" className="submit-button" disabled={!isConnected}>
          {isConnected ? "Registrar Contacto" : "Esperando conexión..."}
        </button>

        {serverResponse && (
          <p className="form-response">📩 Respuesta: {serverResponse}</p>
        )}
      </form>
    </div>
  );
};

export default NuevoContacto;
