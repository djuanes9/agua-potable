import React from "react";
import { Routes, Route, Link } from "react-router-dom";

function IngresarNuevo() {
  return (
    <div>
      <h1>Ingresar Nuevo</h1>
      <nav>
        <ul>
          <li><Link to="poliza">Nueva Póliza</Link></li>
          <li><Link to="aseguradora">Nueva Aseguradora</Link></li>
          <li><Link to="contacto">Nueva Persona de Contacto</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path="poliza" element={<h2>Formulario para Nueva Póliza</h2>} />
        <Route path="aseguradora" element={<h2>Formulario para Nueva Aseguradora</h2>} />
        <Route path="contacto" element={<h2>Formulario para Nueva Persona de Contacto</h2>} />
      </Routes>
    </div>
  );
}

export default IngresarNuevo;
