"use client";
import React, { createContext, useState, useEffect } from "react";
import mqtt from "mqtt";

export const MQTTContext = createContext();

export const MQTTProvider = ({ children }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [mqttClient, setMqttClient] = useState(null);
  const [serverResponse, setServerResponse] = useState(null);

  const [clientesList, setClientesList] = useState([]);
  const [polizasList, setPolizasList] = useState([]);
  const [contactosList, setContactosList] = useState([]); // ✅ nuevo estado

  const brokerUrl = "wss://8624b492419e49889c3ae45df6f03eea.s1.eu.hivemq.cloud:8884/mqtt";
  const mqttUsername = "aseguradora";
  const mqttPassword = "Cg123456";

  // Tópicos clientes
  const topicNuevoCliente = "clientes/nuevo";
  const topicRespuestaCliente = "clientes/respuesta";
  const topicObtenerClientes = "clientes/obtener";
  const topicListaClientes = "clientes/lista";

  // Tópicos pólizas
  const topicObtenerPolizas = "polizas/solicitar";
  const topicListaPolizas = "polizas/lista";

  // Tópicos contactos (nuevo)
  const topicNuevoContacto = "contactos/nuevo";
  const topicRespuestaContacto = "contactos/respuesta";
  const topicObtenerContactos = "contactos/obtener";
  const topicListaContactos = "contactos/lista";

  const initializeMQTTConnection = () => {
    if (!mqttClient) {
      console.log("Conectando al broker MQTT...");

      const client = mqtt.connect(brokerUrl, {
        username: mqttUsername,
        password: mqttPassword,
        reconnectPeriod: 5000,
        connectTimeout: 30 * 1000,
      });

      setMqttClient(client);

      client.on("connect", () => {
        console.log("✅ Conectado al broker MQTT");
        setIsConnected(true);

        client.subscribe(
          [
            topicRespuestaCliente,
            topicListaClientes,
            topicListaPolizas,
            topicRespuestaContacto,
            topicListaContactos,
          ],
          (err) => {
            if (err) console.error("❌ Error de suscripción:", err);
            else
              console.log(
                "📩 Suscrito a:",
                topicRespuestaCliente,
                topicListaClientes,
                topicListaPolizas,
                topicRespuestaContacto,
                topicListaContactos
              );
          }
        );
      });

      client.on("message", (topic, message) => {
        console.log("📨 Recibido en topic:", topic, "→", message.toString());

        if (topic === topicRespuestaCliente || topic === topicRespuestaContacto) {
          setServerResponse(message.toString());
        }

        if (topic === topicListaClientes) {
          try {
            const lista = JSON.parse(message.toString());
            console.log("📦 Lista de clientes recibida:", lista);
            setClientesList(lista);
          } catch (error) {
            console.error("❌ Error al parsear lista de clientes:", error);
          }
        }

        if (topic === topicListaPolizas) {
          try {
            const lista = JSON.parse(message.toString());
            console.log("📑 Lista de pólizas recibida:", lista);
            setPolizasList(lista);
          } catch (error) {
            console.error("❌ Error al parsear lista de pólizas:", error);
          }
        }

        if (topic === topicListaContactos) {
          try {
            const lista = JSON.parse(message.toString());
            console.log("👥 Lista de contactos recibida:", lista);
            setContactosList(lista);
          } catch (error) {
            console.error("❌ Error al parsear lista de contactos:", error);
          }
        }
      });

      client.on("error", (err) => console.error("🚨 Error MQTT:", err));
      client.on("reconnect", () => console.log("🔄 Reintentando conexión..."));
      client.on("offline", () => {
        console.log("❌ Cliente MQTT desconectado");
        setIsConnected(false);
      });
    }
  };

  useEffect(() => {
    initializeMQTTConnection();
    return () => {
      if (mqttClient) mqttClient.end();
    };
  }, [mqttClient]);

  const sendNewClient = (cliente) => {
    if (mqttClient && isConnected) {
      const jsonMessage = JSON.stringify(cliente);
      setServerResponse(null);
      mqttClient.publish(topicNuevoCliente, jsonMessage, {}, (err) => {
        if (err) {
          console.error("🚨 Error al publicar:", err);
          setServerResponse("❌ Error al enviar datos.");
        } else {
          console.log(`📤 Cliente enviado: ${jsonMessage}`);
        }
      });
    } else {
      setServerResponse("❌ No hay conexión con el broker.");
    }
  };

  const sendNewContact = (contacto) => {
    if (mqttClient && isConnected) {
      const jsonMessage = JSON.stringify(contacto);
      setServerResponse(null);
      mqttClient.publish(topicNuevoContacto, jsonMessage, {}, (err) => {
        if (err) {
          console.error("🚨 Error al publicar contacto:", err);
          setServerResponse("❌ Error al enviar contacto.");
        } else {
          console.log(`📤 Contacto enviado: ${jsonMessage}`);
        }
      });
    } else {
      setServerResponse("❌ No hay conexión con el broker.");
    }
  };

  const requestClientesList = () => {
    if (mqttClient && isConnected) {
      mqttClient.publish(topicObtenerClientes, "");
      console.log("📤 Petición enviada: clientes/obtener");
    }
  };

  const requestPolizasList = () => {
    if (mqttClient && isConnected) {
      mqttClient.publish(topicObtenerPolizas, "");
      console.log("📤 Petición enviada: polizas/solicitar");
    }
  };

  const requestContactosList = () => {
    if (mqttClient && isConnected) {
      mqttClient.publish(topicObtenerContactos, "");
      console.log("📤 Petición enviada: contactos/obtener");
    }
  };

  return (
    <MQTTContext.Provider
      value={{
        mqttClient,
        sendNewClient,
        sendNewContact, // ✅ exportar para usar en NuevoContacto.js
        serverResponse,
        isConnected,
        clientesList,
        requestClientesList,
        polizasList,
        requestPolizasList,
        contactosList,
        requestContactosList, // ✅ exportar para usar en Contactos.js si quieres listar
      }}
    >
      {children}
    </MQTTContext.Provider>
  );
};
