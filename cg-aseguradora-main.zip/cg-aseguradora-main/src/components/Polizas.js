import React, { useState, useEffect, useContext } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./Polizas.css";

function Polizas() {
  const {
    polizasList = [],
    requestPolizasList,
    mqttClient,
    isConnected,
  } = useContext(MQTTContext);

  const [filtered, setFiltered] = useState([]);
  const [busqueda, setBusqueda] = useState("");

  useEffect(() => {
    requestPolizasList();
  }, []);

  useEffect(() => {
    setFiltered(polizasList);
  }, [polizasList]);

  useEffect(() => {
    const lower = busqueda.toLowerCase();
    const filtro = polizasList.filter(
      (p) =>
        p.numeroPoliza?.toLowerCase().includes(lower) ||
        p.representante?.toLowerCase().includes(lower)
    );
    setFiltered(filtro);
  }, [busqueda, polizasList]);

  const formatFecha = (fechaISO) => {
    if (!fechaISO) return "-";
    const fecha = new Date(fechaISO);
    return fecha.toLocaleDateString("es-EC", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const eliminarPoliza = (numeroPoliza, numeroRenovacion) => {
    const confirmar = window.confirm(
      `¿Estás seguro de que deseas eliminar la póliza ${numeroPoliza} (Renovación ${numeroRenovacion})?`
    );
    if (confirmar && mqttClient && isConnected) {
      const payload = JSON.stringify({ numeroPoliza, numeroRenovacion });
      mqttClient.publish("polizas/eliminar", payload, {}, (err) => {
        if (err) {
          console.error("❌ Error al publicar eliminación:", err);
        } else {
          console.log(`🗑️ Eliminación publicada: ${payload}`);
          setTimeout(() => {
            requestPolizasList();
          }, 1000);
        }
      });
    }
  };

  return (
    <div className="polizas-container">
      <h2 className="titulo">📋 Consulta de Pólizas</h2>
      <input
        type="text"
        className="buscador"
        placeholder="Buscar por número de póliza o representante..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />
      <div className="tabla-wrapper">
        <table className="tabla">
          <thead>
            <tr>
              <th>Razón Social</th>
              <th>Representante</th>
              <th>CI/RUC</th>
              <th>Tipo</th>
              <th>Nº Póliza</th>
              <th>Placa</th>
              <th>Código Asegurado</th>
              <th>F. Emisión</th>
              <th>Renovación</th>
              <th>Vigencia Desde</th>
              <th>Vigencia Hasta</th>
              <th>Aseguradora</th>
              <th>Prima Neta</th>
              <th>Valor Total</th>
              <th>Forma Pago</th>
              <th>Doc. Pago</th>
              <th>En Cuotas</th>
              <th>N° Cuotas</th>
              <th>Inicio Pago</th>
              <th>Verificado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p, i) => (
              <tr key={i}>
                <td>{p.razonSocial}</td>
                <td>{p.representante}</td>
                <td>{p.ciRuc}</td>
                <td>{p.tipoPoliza}</td>
                <td>{p.numeroPoliza}</td>
                <td>{p.placa}</td>
                <td>{p.codigoAsegurado}</td>
                <td>{formatFecha(p.fechaEmision)}</td>
                <td>{p.numeroRenovacion}</td>
                <td>{formatFecha(p.vigenciaDesde)}</td>
                <td>{formatFecha(p.vigenciaHasta)}</td>
                <td>{p.aseguradora}</td>
                <td>${parseFloat(p.primaNeta).toFixed(2)}</td>
                <td>${parseFloat(p.valorTotal).toFixed(2)}</td>
                <td>{p.formaPago}</td>
                <td>{p.numeroDocumento}</td>
                <td>{p.pagoEnCuotas}</td>
                <td>{p.numeroCuotas}</td>
                <td>{formatFecha(p.fechaPagoInicial)}</td>
                <td>{p.verificado === 1 ? "✅" : "❌"}</td>
                <td>
                  <button
                    className="btn-eliminar"
                    onClick={() =>
                      eliminarPoliza(p.numeroPoliza, p.numeroRenovacion)
                    }
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="mensaje-vacio">Sin resultados</p>
        )}
      </div>
    </div>
  );
}

export default Polizas;
