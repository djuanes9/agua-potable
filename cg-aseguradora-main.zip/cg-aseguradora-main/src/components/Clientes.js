import React, { useState, useEffect, useContext } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./Polizas.css"; // Reutilizamos el estilo existente para mantener coherencia visual

function Clientes() {
  const { clientesList = [], requestClientesList, mqttClient, isConnected } = useContext(MQTTContext);

  const [filtered, setFiltered] = useState([]);
  const [busqueda, setBusqueda] = useState("");

  useEffect(() => {
    requestClientesList(); // Solicita los datos desde MQTT al cargar
  }, []);

  useEffect(() => {
    setFiltered(clientesList);
  }, [clientesList]);

  useEffect(() => {
    const lower = busqueda.toLowerCase();
    const filtro = clientesList.filter(
      (c) =>
        c.razonSocial?.toLowerCase().includes(lower) ||
        c.representante?.toLowerCase().includes(lower) ||
        c.ciRuc?.toLowerCase().includes(lower)
    );
    setFiltered(filtro);
  }, [busqueda, clientesList]);

  const formatFecha = (fechaISO) => {
    if (!fechaISO) return "-";
    const fecha = new Date(fechaISO);
    return fecha.toLocaleDateString("es-EC", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const eliminarCliente = (ciRuc) => {
    const confirmar = window.confirm(
      `¿Estás seguro de que deseas eliminar el cliente con CI/RUC ${ciRuc}?`
    );
    if (confirmar && mqttClient && isConnected) {
      const payload = JSON.stringify({ ciRuc });
      mqttClient.publish("clientes/eliminar", payload, {}, (err) => {
        if (err) {
          console.error("❌ Error al publicar eliminación:", err);
        } else {
          console.log(`🗑️ Eliminación de cliente publicada: ${payload}`);
          setTimeout(() => {
            requestClientesList(); // refrescar lista
          }, 1000);
        }
      });
    }
  };

  return (
    <div className="polizas-container">
      <h2 className="titulo">🧾 Consulta de Clientes</h2>
      <input
        type="text"
        className="buscador"
        placeholder="Buscar por RUC, razón social o representante..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />
      <div className="tabla-wrapper">
        <table className="tabla">
          <thead>
            <tr>
              <th>Razón Social</th>
              <th>Representante</th>
              <th>CI/RUC</th>
              <th>Dirección</th>
              <th>Celular</th>
              <th>Teléfono</th>
              <th>Correo</th>
              <th>Fecha Nacimiento</th>
              <th>Agente</th>
              <th>Registro</th>
              <th>Acciones</th> {/* Nueva columna para eliminar */}
            </tr>
          </thead>
          <tbody>
            {filtered.map((c, i) => (
              <tr key={i}>
                <td>{c.razonSocial}</td>
                <td>{c.representante}</td>
                <td>{c.ciRuc}</td>
                <td>{c.direccion}</td>
                <td>{c.celular}</td>
                <td>{c.telefono}</td>
                <td>{c.correo}</td>
                <td>{formatFecha(c.fechaNacimiento)}</td>
                <td>{c.agente}</td>
                <td>{formatFecha(c.fechaRegistro)}</td>
                <td>
                  <button
                    className="btn-eliminar"
                    onClick={() => eliminarCliente(c.ciRuc)}
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="mensaje-vacio">Sin resultados</p>
        )}
      </div>
    </div>
  );
}

export default Clientes;
