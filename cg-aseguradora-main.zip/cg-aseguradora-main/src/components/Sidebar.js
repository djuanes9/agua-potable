// src/components/Sidebar.js

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import "./Sidebar.css";

function Sidebar({ user, onLogout, isOpen }) {
  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const renderMenuTitle = (title, menuKey) => (
    <span>
      {title} {openMenu === menuKey ? "▲" : "▼"}
    </span>
  );

  return (
    <div className={`sidebar ${isOpen ? "open" : "closed"}`}>
      {/* Logo */}
      <img
        src="/logo.png"
        alt="CG Asesores de Seguros"
        className="sidebar-logo"
      />

      {/* Botón Inicio */}
      <Link to="/" className="inicio-btn">
        🏠 Inicio
      </Link>

      {/* Menú de navegación */}
      <nav>
        <ul>
          {/* Ingresar Nuevo */}
          <li onClick={() => toggleMenu("ingresarNuevo")}>
            {renderMenuTitle("Ingresar Nuevo", "ingresarNuevo")}
            <AnimatePresence initial={false}>
              {openMenu === "ingresarNuevo" && (
                <motion.ul
                  initial={{ maxHeight: 0, opacity: 0 }}
                  animate={{ maxHeight: 500, opacity: 1 }}
                  exit={{ maxHeight: 0, opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="submenu"
                >
                  <li>
                    <Link to="/ingresar-nuevo/cliente">Nuevo Cliente</Link>
                  </li>
                  <li>
                    <Link to="/ingresar-nuevo/poliza">Nueva Póliza</Link>
                  </li>

                  <li>
                    <Link to="/ingresar-nuevo/contacto">
                      Nueva Persona de Contacto
                    </Link>
                  </li>
                </motion.ul>
              )}
            </AnimatePresence>
          </li>

          {/* Consulta */}
          <li onClick={() => toggleMenu("consulta")}>
            {renderMenuTitle("Consulta", "consulta")}
            <AnimatePresence initial={false}>
              {openMenu === "consulta" && (
                <motion.ul
                  initial={{ maxHeight: 0, opacity: 0 }}
                  animate={{ maxHeight: 500, opacity: 1 }}
                  exit={{ maxHeight: 0, opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="submenu"
                >
                  <li>
                    <Link to="/consulta/polizas">Consultar Pólizas</Link>
                  </li>
                  <li>
                    <Link to="/consulta/clientes">Consultar Clientes</Link>
                  </li>
                  <li>
                    <Link to="/consulta/cuotas">
                      Consultar Cuotas Mensuales
                    </Link>
                  </li>
                  <li>
                    <Link to="/consulta/contactos">
                      Consultar Personas de Contacto
                    </Link>
                  </li>
                </motion.ul>
              )}
            </AnimatePresence>
          </li>
        </ul>
      </nav>

      {/* Sección del usuario */}
      {user && (
        <div className="user-section">
          <p>👤 {user.name}</p>
          <button className="logout-btn" onClick={onLogout}>
            Cerrar Sesión
          </button>
        </div>
      )}
    </div>
  );
}

export default Sidebar;
