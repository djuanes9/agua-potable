import React from "react";
import { Routes, Route, Link } from "react-router-dom";

function Consulta() {
  return (
    <div>
      <h1>Consulta</h1>
      <nav>
        <ul>
          <li><Link to="polizas">Consultar Pólizas</Link></li>
          <li><Link to="contactos">Consultar Personas de Contacto</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path="polizas" element={<h2>Listado de Pólizas</h2>} />
        <Route path="contactos" element={<h2>Listado de Personas de Contacto</h2>} />
      </Routes>
    </div>
  );
}

export default Consulta;
