"use client";
import React, { useState, useEffect, useContext } from "react";
import { MQTTContext } from "./MQTTCliente";
import "./Contactos.css"; // Estilo separado (puedes copiar Clientes.css como base)

function Contactos() {
  const { contactosList = [], requestContactosList } = useContext(MQTTContext);
  const [filtered, setFiltered] = useState([]);
  const [busqueda, setBusqueda] = useState("");

  useEffect(() => {
    requestContactosList(); // ✅ Pedir contactos cuando se abre esta vista
  }, []);

  useEffect(() => {
    setFiltered(contactosList);
  }, [contactosList]);

  useEffect(() => {
    const lower = busqueda.toLowerCase();
    const filtro = contactosList.filter(
      (c) =>
        c.nombre.toLowerCase().includes(lower) ||
        c.correo.toLowerCase().includes(lower)
    );
    setFiltered(filtro);
  }, [busqueda, contactosList]);

  return (
    <div className="contactos-container">
      <h2 className="contactos-title">Personas de Contacto Registradas</h2>

      <input
        type="text"
        placeholder="Buscar por nombre o correo..."
        className="contactos-search"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />

      <div className="table-wrapper">
        <table className="contactos-table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Teléfono</th>
              <th>Correo</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length > 0 ? (
              filtered.map((contacto, index) => (
                <tr key={index}>
                  <td>{contacto.nombre}</td>
                  <td>{contacto.telefono}</td>
                  <td>{contacto.correo}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="3">No se encontraron contactos.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Contactos;
