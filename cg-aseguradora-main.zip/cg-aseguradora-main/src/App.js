import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Sidebar from "./components/Sidebar";
import IngresarNuevo from "./components/IngresarNuevo";
import Consulta from "./components/Consulta";
import Login from "./components/Login";
import NuevaPoliza from "./components/NuevaPoliza";
import NuevoCliente from "./components/NuevoCliente";
import NuevoContacto from "./components/NuevoContacto"; // ✅ NUEVO
import Inicio from "./components/Inicio";
import Polizas from "./components/Polizas";
import Clientes from "./components/Clientes";
import Cuotas from "./components/Cuotas";
import Contactos from "./components/Contactos"; // ✅ NUEVO
import { MQTTProvider } from "./components/MQTTCliente";
import "./App.css";

function App() {
  const [user, setUser] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setSidebarOpen(true);
    }
  }, []);

  const handleLogin = (username, password) => {
    if (username === "admin" && password === "1234") {
      const userData = { name: username };
      localStorage.setItem("user", JSON.stringify(userData));
      setUser(userData);
      setSidebarOpen(true);
    } else {
      alert("Credenciales incorrectas");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    setSidebarOpen(false);
  };

  return (
    <MQTTProvider>
      <Router>
        <div className="app-container">
          {user && (
            <>
              <button
                className="toggle-btn"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                ☰
              </button>
              <Sidebar
                user={user}
                onLogout={handleLogout}
                isOpen={sidebarOpen}
              />
            </>
          )}
          <div
            className={`content ${
              sidebarOpen ? "content-shift" : "content-full"
            }`}
          >
            <Routes>
              <Route
                path="/login"
                element={
                  user ? <Navigate to="/" /> : <Login onLogin={handleLogin} />
                }
              />
              <Route
                path="/"
                element={user ? <Inicio /> : <Navigate to="/login" />}
              />
              <Route
                path="/ingresar-nuevo"
                element={user ? <IngresarNuevo /> : <Navigate to="/login" />}
              />
              <Route
                path="/consulta"
                element={user ? <Consulta /> : <Navigate to="/login" />}
              />
              <Route
                path="/ingresar-nuevo/poliza"
                element={user ? <NuevaPoliza /> : <Navigate to="/login" />}
              />
              <Route
                path="/ingresar-nuevo/cliente"
                element={user ? <NuevoCliente /> : <Navigate to="/login" />}
              />
              <Route
                path="/ingresar-nuevo/contacto"
                element={user ? <NuevoContacto /> : <Navigate to="/login" />}
              />{" "}
              {/* ✅ Nueva Persona de Contacto */}
              <Route
                path="/consulta/polizas"
                element={user ? <Polizas /> : <Navigate to="/login" />}
              />
              <Route
                path="/consulta/clientes"
                element={user ? <Clientes /> : <Navigate to="/login" />}
              />
              <Route
                path="/consulta/cuotas"
                element={user ? <Cuotas /> : <Navigate to="/login" />}
              />
              <Route
                path="/consulta/contactos"
                element={user ? <Contactos /> : <Navigate to="/login" />}
              />{" "}
              {/* ✅ Consultar Personas de Contacto */}
            </Routes>
          </div>
        </div>
      </Router>
    </MQTTProvider>
  );
}

export default App;
